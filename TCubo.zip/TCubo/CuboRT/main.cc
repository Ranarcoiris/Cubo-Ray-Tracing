#include "rtweekend.h"
#include "camera.h"
#include "hittable_list.h"
#include "sphere.h"
#include "material.h"

int main() {
    hittable_list world;

    // Plano (suelo)
    auto ground_material = make_shared<lambertian>(color(0.5, 0.5, 0.5));
    world.add(make_shared<sphere>(point3(0, -1000, 0), 1000, ground_material));

    // Suelo adicional (plano rectangular)
    int floor_size = 20;
    double floor_height = 0.95;
    for (int x = -floor_size; x <= floor_size; x++) {
        for (int z = -floor_size; z <= floor_size; z++) {
            point3 center(x * 0.5, floor_height, z * 0.5);
            world.add(make_shared<sphere>(center, 0.05, ground_material));
        }
    }

    // Material de las esferas (rojo oscuro)
    auto sphere_material = make_shared<lambertian>(color(0.6, 1, 0.1));


    int num_spheres = 5;    // N�mero de esferas por cara
    double spacing = 0.4;   // Espaciado entre las esferas
    double radius = 0.15;   // Radio de cada esfera
    double cube_size = (num_spheres - 1) * spacing;

    // Generaci�n de esferas para formar un cubo
    for (int x = 0; x < num_spheres; x++) {
        for (int y = 0; y < num_spheres; y++) {
            for (int z = 0; z < num_spheres; z++) {
                // Crear solo las caras del cubo (no esferas interiores)
                if (x == 0 || x == num_spheres - 1 || y == 0 || y == num_spheres - 1 || z == 0 || z == num_spheres - 1) {
                    point3 center(
                        x * spacing - cube_size / 2,
                        y * spacing + 1.0,  // Levantar el cubo sobre el suelo
                        z * spacing - cube_size / 2
                    );
                    world.add(make_shared<sphere>(center, radius, sphere_material));
                }
            }
        }
    }

    int pyramid_levels = 5;
    double pyramid_spacing = 0.4;
    point3 pyramid_base_pos(2.5, 1.0, 0);  // Posici�n base de la pir�mide

    // Generaci�n de esferas para formar una pir�mide
    for (int level = 0; level < pyramid_levels; level++) {
        int num_spheres_level = pyramid_levels - level;
        double y_offset = level * spacing;
        for (int i = 0; i < num_spheres_level; i++) {
            for (int j = 0; j < num_spheres_level; j++) {
                point3 center(
                    pyramid_base_pos.x() + (i - num_spheres_level / 2.0) * pyramid_spacing,
                    pyramid_base_pos.y() + y_offset,
                    pyramid_base_pos.z() + (j - num_spheres_level / 2.0) * pyramid_spacing
                );
                world.add(make_shared<sphere>(center, radius, sphere_material));
            }
        }
    }

    // Configuraci�n de la c�mara
    camera cam;
    cam.aspect_ratio = 16.0 / 9.0;
    cam.image_width = 400;
    cam.samples_per_pixel = 50;
    cam.max_depth = 20;

    cam.vfov = 20;
    cam.lookfrom = point3(8, 5, 10);  // Posici�n de la c�mara
    cam.lookat = point3(0, 1, 0);    // Punto donde mira la c�mara
    cam.vup = vec3(0, 1, 0);

    cam.defocus_angle = 0.0;  // Sin efecto de profundidad de campo
    cam.focus_dist = 10.0;

    cam.render(world);  // Renderizar la escena

    return 0;
}


//Hasta este cambio tengo el codigo funciona con el cubo 5X5 funcional 